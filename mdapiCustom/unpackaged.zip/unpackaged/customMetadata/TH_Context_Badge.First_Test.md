<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>First Test</label>
    <protected>false</protected>
    <values>
        <field>Badge_Id__c</field>
        <value xsi:type="xsd:string">a002E00000YwkqwQAB</value>
    </values>
    <values>
        <field>Field_API_Name__c</field>
        <value xsi:type="xsd:string">StageName</value>
    </values>
    <values>
        <field>Field_Value__c</field>
        <value xsi:type="xsd:string">Prospecting</value>
    </values>
    <values>
        <field>Object_API_Name__c</field>
        <value xsi:type="xsd:string">Opportunity</value>
    </values>
</CustomMetadata>
